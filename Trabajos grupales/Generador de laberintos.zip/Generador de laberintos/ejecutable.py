import Laberinto
ancho = Laberinto.ancho
alto = Laberinto.alto

lab = Laberinto.InicializaLaberinto(ancho,alto)
laberinto=Laberinto.NuevoLaberinto(lab)


posicion=[Laberinto.GetEntrada(laberinto),0]
Salida = [Laberinto.Getsalida(laberinto),ancho-1]
accion = ''
# -----
def render(lab_) :
    return Laberinto.ImprimeLaberinto(lab_)

def Restart(lab_):
    lab_= Laberinto.InicializaLaberinto(ancho,alto)
    laberinto=Laberinto.NuevoLaberinto(lab_)
    laberinto[Laberinto.GetEntrada(laberinto)][0]='x'
    render(laberinto)

def Decidir(posible):
    if (posible=='r'):
        Restart(lab)
        print('nuevo laberinto')
    elif (posible=='w' or posible=='a' or posible=='s' or posible=='d'):
        Moverse(posible)
    else:
        print('intenta otra vez')

#print(ran(5))
def Moverse(direccion):
    if (direccion=='w' and posicion[0]>0 and lab[posicion[0]-1][posicion[1]]==' '):
        laberinto[posicion[0]][posicion[1]]=' '
        laberinto[posicion[0]-1][posicion[1]]='x'
        posicion[0]-=1
        render(laberinto)

    elif (direccion=='s' and posicion[0]<alto -1 and lab[posicion[0]+1][posicion[1]]==' '):
        laberinto[posicion[0]][posicion[1]]=' '
        laberinto[posicion[0]+1][posicion[1]]='x'
        posicion[0]+=1
        render(laberinto)
    
    elif(direccion=='a' and posicion[1]>0 and lab[posicion[0]][posicion[1]-1]==' '):
        laberinto[posicion[0]][posicion[1]]=' '
        laberinto[posicion[0]][posicion[1]-1]='x'
        posicion[1]-=1
        render(laberinto)

    elif (direccion=='d' and posicion[1]<ancho -1 and lab[posicion[0]][posicion[1]+1]==' '):
        laberinto[posicion[0]][posicion[1]]=' '
        laberinto[posicion[0]][posicion[1]+1]='x'
        posicion[1]+=1
        render(laberinto)
print('''\n\n\n generador de laberintos 
        
controles: debe presionar enter 
para que cada intruccion se registre

arriba: w 
abajo: s
izquierda: a
derecha: d
generar otro laberinto: r 
salir: e
''')

 

Restart(laberinto)
while(True):
    if posicion == Salida:
        print('Ha Completado el laberinto')
        break
    accion=input('')
    if (accion=='e'):
       break
    Decidir(accion.lower())

