from random import uniform as rFloat
def rInt(a,b):
    return int(rFloat(a,b))

ancho = 60
alto = 30


# laberinto en crudo
def InicializaLaberinto(an,al):
    laberinto_ = []
    def FilaPuntos(x):
        fila=[]
        for i in range(an):
            fila.append('.')
        return x.append(fila)

    def ColumnaPuntos(x):
        for u in range(al):
            FilaPuntos(x)
        return x
    return ColumnaPuntos(laberinto_)
    
lbto = InicializaLaberinto(ancho,alto)
# -----------------------------------------

# gusano arma laberintos

def NuevoLaberinto(lbto_):
    entra = rInt(1,alto-1)
    entrada = [entra,0]
    vBuffer = [entrada]
    gusanoPos = []

    def MarcarBordes(_lbto_):
        for i in range(ancho):
            _lbto_[0][i] = '0'
            _lbto_[alto-1][i] = '0'
        for i in range(alto):
            _lbto_[i][0] = '0'
            _lbto_[i][ancho-1] = '0'
        return _lbto_
    
    def BuscarVirg(pos,_lbto_):
        vecinos=[ 
                [pos[0]-1,pos[1]],  #arriba
                [pos[0]+1,pos[1]],  #abajo
                [pos[0],pos[1]-1],  #izquierda
                [pos[0],pos[1]+1]   #derecha
                ]
        cVirgen = []
        for i in range(4):
            if (_lbto_[vecinos[i][0]][vecinos[i][1]]=='.'):
                cVirgen.append(vecinos[i])
        return cVirgen

    def PonerPared(pos1,pos2,_lbto_):
        if _lbto_[pos1[0]][pos1[1]]=='.':
            _lbto_[pos1[0]][pos1[1]] = '0'
        if _lbto_[pos2[0]][pos2[1]] == '.':
            _lbto_[pos2[0]][pos2[1]] = '0'
        return _lbto_
    def PonerCamino(gpos,gspos,_lbto_):
        _lbto_[gpos[0]][gpos[1]] = ' '
        _lbto_[gspos[0]][gspos[1]] = ' '
        return _lbto_
    
    def BufferNoVacio():
        return not vBuffer==[]

    def Excavar(_lbto_):
        cInicial = [entra,1]
        gusanoPos = [cInicial[0],cInicial[1]]
        bandera = not vBuffer==[]
        lbto_[entrada[0]][entrada[1]] = ' '
        i=0   
        while (BufferNoVacio() and i<900):
            gArriba = [gusanoPos[0]-1,gusanoPos[1]]
            gAbajo = [gusanoPos[0]+1,gusanoPos[1]]
            gIzquierda = [gusanoPos[0],gusanoPos[1]-1]
            gDerecha = [gusanoPos[0],gusanoPos[1]+1]

            virg=BuscarVirg(gusanoPos,_lbto_)

            while (virg==[]and BufferNoVacio()):
                gusanoPos=[vBuffer[-1][0],vBuffer[-1][1]]
                vBuffer.pop(-1)
                virg=BuscarVirg(gusanoPos,_lbto_)
            if (virg!=[]and BufferNoVacio()):

                vElegegida=rInt(0,len(virg))
                posVElegida=[virg[vElegegida][0],virg[vElegegida][1]]
                if posVElegida[0]==gusanoPos[0]:
                    _lbto_ =  PonerPared(gArriba,gAbajo,_lbto_) #poner paredes arriba y abajo si no hay ya unas puestas 
                    _lbto_ = PonerCamino(gusanoPos,posVElegida,_lbto_)
                    vBuffer.append(gusanoPos)
                    gusanoPos = [posVElegida[0],posVElegida[1]]
                else:
                    _lbto_ = PonerPared(gDerecha,gIzquierda,_lbto_)
                    _lbto_ = PonerCamino(gusanoPos,posVElegida,_lbto_)
                    vBuffer.append(gusanoPos)
                    gusanoPos = [posVElegida[0],posVElegida[1]]
            i+=1

        
        return _lbto_
    
    def Salida(_lbto_):
        posibles=[]
        for i in range(alto):
            if _lbto_[i][ancho-2] == ' ' :
                posibles.append(i)
        #    print(posibles)
        _lbto_[posibles[rInt(0,len(posibles))]][ancho-1] = ' '
        return _lbto_

    lbto_ = MarcarBordes(lbto_)
    lbto_ = Excavar(lbto_)
    lbto_ = Salida(lbto_)
    return lbto_


def GetEntrada(lbto_):
    for i in range(alto):
        if lbto_[i][0]==' ':
            return i
def Getsalida(lbto_):
    for i in range(alto):
        if lbto_[i][ancho-1]==' ':
            return i



def UneFilas(fila):
    filaUnida=''
    for i in range(len(fila)):
        filaUnida+=fila[i]
    return filaUnida

def ImprimeLaberinto(laberinto):
    imagen='\n'
    for i in range(len(laberinto)):
        imagen+=UneFilas(laberinto[i])
        imagen+='\n'
    print(imagen)



